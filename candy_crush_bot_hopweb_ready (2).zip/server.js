const express = require('express');
const TelegramBot = require('node-telegram-bot-api');
require('dotenv').config();

const app = express();
const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

let users = {};

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  if (!users[chatId]) users[chatId] = 0;

  const opts = {
    reply_markup: {
      inline_keyboard: [[{ text: "Tap to Earn Coins", callback_data: "tap" }]]
    }
  };
  bot.sendMessage(chatId, "Welcome to Candy Crush Coins Candy!", opts);
});

bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  if (!users[chatId]) users[chatId] = 0;
  users[chatId] += 1;

  bot.answerCallbackQuery(callbackQuery.id, { text: `You have ${users[chatId]} coins.` });
});

app.get("/", (req, res) => {
  res.send("Candy Crush Bot is running!");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
