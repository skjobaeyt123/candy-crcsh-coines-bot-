# Candy Crush Coins Candy Bot

This is a simple Telegram bot built with Node.js to simulate a "tap to earn" game.

## Setup

1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env` and add your BOT_TOKEN
3. Run: `node server.js`
