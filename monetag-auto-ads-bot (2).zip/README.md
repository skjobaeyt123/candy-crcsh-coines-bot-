# Auto Monetag Ads Bot

This is a Telegram Mini App bot interface that auto-shows Monetag ads every 30 seconds and rewards users.

- Built with Flask
- Hosted via Vercel
- Monetag integrated